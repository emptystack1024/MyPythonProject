%% 初始化
clear ; close all; clc

%% 设置参数
input_layer_size  = 400;  % 数字输入图像大小：20*20
num_labels = 10;          % 10个标签

%% =========== Part 1: 加载数据和表示数据 =============

% 加载数据
fprintf('加载和展示数据 ...\n')

load('ex3data1.mat');
m = size(X, 1);

% Randomly select 100 data points to display
rand_indices = randperm(m);
sel = X(rand_indices(1:100), :);

displayData(sel);

fprintf('程序暂停。按回车键继续。\n');
pause;

%% ================ Part 2: 加载参数 ================
% 加载一些预初始化的神经网络参数

fprintf('\n使用正则化测试lrCostFunction()');

theta_t = [-2; -1; 1; 2];
X_t = [ones(5,1) reshape(1:15,5,3)/10];
y_t = ([1;0;1;0;1] >= 0.5);
lambda_t = 3;
[J grad] = lrCostFunction(theta_t, X_t, y_t, lambda_t);

fprintf('\n代价：%f\n', J);
fprintf('预期代价: 2.534819\n');
fprintf('梯度:\n');
fprintf(' %f \n', grad);
fprintf('预期梯度:\n');
fprintf(' 0.146561\n -0.548558\n 0.724722\n 1.398003\n');

fprintf('程序暂停。按回车键继续。\n');
pause;
%% ============ Part 2b: 一对多训练 ============
fprintf('\n训练 "一对多 "逻辑回归...\n')

lambda = 0.1;
[all_theta] = oneVsAll(X, y, num_labels, lambda);

fprintf('程序暂停。按回车键继续。\n');
pause;


%% ================ Part 3: 预测一对多 ================

pred = predictOneVsAll(all_theta, X);

fprintf('\n训练集精度: %f\n', mean(double(pred == y)) * 100);

