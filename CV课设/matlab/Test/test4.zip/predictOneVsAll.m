function p = predictOneVsAll(all_theta, X)
% 为训练有素的单一分类器预测标签。标签范围为 1...K，其中 K = size(all_theta,1)。

m = size(X, 1);
num_labels = size(all_theta, 1);

p = zeros(size(X, 1), 1);

X = [ones(m, 1) X];

% 使用 max 函数可以将这些代码全部矢量化。
% 特别是，max 函数还可以返回最大元素的索引。   
h=all_theta*X';
[~,t]=max(h);
p=t';

end
